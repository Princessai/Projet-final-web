<?php
namespace App\Enums;
 enum roleEnum: string
{

    // case Etudiant="etudiant";
    // case Parent="parent";
    // case Enseignant="enseignant";
    // case Coordinateur="coordinateur";
    // case Admin="admin";
    case Etudiant="student";
    case Parent="parent";
    case Enseignant="teacher";
    case Coordinateur="coordinator";
    case Admin="admin";
   
}