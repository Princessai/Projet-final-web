<?php

namespace App\Enums;

enum absenceStateEnum: int
{
    case notJustified = 0;
    case justified = 1;
   
}
