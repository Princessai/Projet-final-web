<?php

namespace App\Enums;

enum coursStateEnum: int
{
    case notTerminated = 0;
    case terminated = 1;
}
