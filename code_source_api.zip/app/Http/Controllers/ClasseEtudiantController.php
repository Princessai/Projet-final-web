<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClasseEtudiantController extends Controller
{
    //
}
