<?php

namespace Database\Factories;

use App\Models\CourseHour;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Course_hour>
 */
class CourseHourFactory extends Factory
{


    protected $model = CourseHour::class;
/**
 * Create a new factory instance for the model.
 */

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //
        ];
    }
}
