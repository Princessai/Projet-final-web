<?php

return  [
    "javascript",
    "petchkucha",
    "electron",
    "photoshop",
    "illustrator",
    "wordpress"
];
