<?php

return [
    'prepa'=>["label"=>"Annee preparatoire" , "alias"=>"Prepa"],
    'B2'=>["label"=>"Bachelor 2" , "alias"=>"B2"],
    'B3'=>["label"=>"Bachelor 3" , "alias"=>"B3"]
];