<?php
return [
    "etudiant",
    "parent",
    "enseignant",
    "coordinateur",
    "admin"
];
