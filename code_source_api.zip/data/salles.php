<?php

$salles = [];

for ($i = 1; $i <= 10; $i++) {
    $salles[] = "Salle" . $i;
}
$salles[] = "Amphi";


return  $salles;
