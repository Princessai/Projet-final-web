<?php 

return   [
    ["name" => "aprem", "debut" => "15:45", "fin" => 16, "isIncluded" => true],
    ["name" => "midi", "debut" => 12, "fin" => 14, "isIncluded" => false],
    ["name" => "recreation", "debut" => "10:45", "fin" => 11, "isIncluded" => true],
    // ["name" => "essai", "debut" => "14:45", "fin" => 15, "isIncluded" => true],
    // ["name" => "essai2", "debut" => 15, "fin" => "15:15", "isIncluded" => true],
    // ["name" => "essai3", "debut" => 9, "fin" => "9:15", "isIncluded" => true],
    // ["name" => "essai3", "debut" => "16:30", "fin" => "16:45", "isIncluded" => false],
];
