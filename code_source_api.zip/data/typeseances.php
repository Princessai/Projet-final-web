<?php

return [
    "presentiel",
    "workshop",
    "e-learning",
    "rendu",
    "examen"
];
