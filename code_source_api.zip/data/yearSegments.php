<?php

// $segments = [
//     ['type' => 'Trimestre', 'number' => 1, 'start' => '2023-10-02', 'end' => '2024-01-02'],
//     ['type' => 'Trimestre', 'number' => 2, 'start' => '2024-01-02', 'end' => '2024-04-02'],
//     ['type' => 'Trimestre', 'number' => 3, 'start' => '2024-04-02', 'end' => '2024-07-02'],
// ];
$segments = [
    ['type' => 'Semestre', 'number' => 1, 'start' => '2023-10-02', 'end' => '2024-02-28'],
    ['type' => 'Semestre', 'number' => 2, 'start' => '2024-02-28', 'end' => '2024-06-25'],
    ['type' => 'Semestre', 'number' => 3, 'start' => '2024-06-25', 'end' => '2024-10-25'],
];

return $segments;
