<?php

return [
    "mixte"=>["label"=>"Tronc commun",],
    'communication'=>["label"=>"Communication Digitale","alias"=>"Com"],
    'creation'=>["label"=>"Creation Digitale","alias"=>"Crea"],
    'developpement'=>["label"=>"Developpement Web","alias"=>"Dev"]
];