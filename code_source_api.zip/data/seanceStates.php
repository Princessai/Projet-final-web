<?php

return [
    "annule",
    "workshop",
    "e-learning",
    "rendu",
    "examen"
];
